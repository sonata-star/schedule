package com.example.schedule.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.schedule.presentation.components.AppPalette
import com.example.schedule.presentation.components.DAY_NAMES
import com.example.schedule.presentation.components.currentScheduleDayIndex
import com.example.schedule.presentation.components.timeText
import com.example.domain.model.Lesson
import java.util.Locale

private data class EditSlot(
    var day: String,
    var start: Int,
    var end: Int
)
@Composable
fun LessonEditorScreen(
    oldTitle: String?,
    allLessons: List<Lesson>,
    duration: Int,
    palette: AppPalette,
    accountType: String,
    onBack: () -> Unit,
    onSave: (String?, String, List<Lesson>) -> Unit,
    onDelete: (String) -> Unit
) {
    var title by remember(oldTitle) {
        mutableStateOf(oldTitle.orEmpty())
    }
    val original = allLessons.firstOrNull { it.title.equals(oldTitle, ignoreCase = true) && it.accountType == accountType }
    var cabinet by remember(oldTitle, accountType, allLessons) { mutableStateOf(original?.cabinet.orEmpty()) }
    var teacher by remember(oldTitle, accountType, allLessons) { mutableStateOf(original?.teacher.orEmpty()) }
    var subject by remember(oldTitle, accountType, allLessons) { mutableStateOf(original?.subject.orEmpty()) }

    val slots = remember(oldTitle, allLessons, duration) {
        mutableStateListOf<EditSlot>().apply {
            val matching = allLessons.filter {
                it.title.equals(oldTitle, ignoreCase = true) && it.accountType == accountType
            }

            if (matching.isEmpty()) {
                val start = 480
                add(
                    EditSlot(
                        DAY_NAMES[currentScheduleDayIndex()],
                        start,
                        start + duration
                    )
                )
            } else {
                matching.forEach {
                    add(
                        EditSlot(
                            it.dayOfWeek,
                            it.startTime,
                            it.endTime
                        )
                    )
                }
            }
        }
    }

    var error by remember {
        mutableStateOf<String?>(null)
    }

    var editingTime by remember {
        mutableStateOf<Pair<Int, Boolean>?>(null)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = palette.text
                )
            }

            TextButton(
                onClick = {
                    val normalized = title.trim().replaceFirstChar {
                        if (it.isLowerCase()) {
                            it.titlecase(Locale("ru"))
                        } else {
                            it.toString()
                        }
                    }

                    when {
                        normalized.isBlank() ->
                            error = if (accountType == "STUDENT") "Введите название предмета." else "Введите ФИО ученика или класс."

                        slots.isEmpty() ->
                            error = "Добавьте хотя бы один день."

                        slots.any { it.start !in 0..1439 ||
                                it.end !in 1..1440 ||
                                it.end <= it.start
                        } ->
                            error = "Проверьте время начала и окончания."

                        else -> onSave(
                            oldTitle,
                            normalized,
                            slots.map {
                                Lesson(
                                    title = normalized,
                                    startTime = it.start,
                                    endTime = it.end,
                                    dayOfWeek = it.day,
                                    cabinet = cabinet.trim(),
                                    teacher = teacher.trim(),
                                    subject = subject.trim(),
                                    accountType = accountType
                                )
                            }
                        )
                    }
                }
            ) {
                Text("Сохранить", color = palette.text)
            }
        }

        OutlinedTextField(
            value = title,
            onValueChange = { title = it.take(20) },
            label = { Text(if (accountType == "STUDENT") "Название предмета" else "ФИО ученика или класс") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        if (accountType == "STUDENT") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it.take(80) },
                    label = { Text("ФИО учителя") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = cabinet,
                    onValueChange = { cabinet = it.take(30) },
                    label = { Text("Кабинет") },
                    singleLine = true,
                    modifier = Modifier.width(112.dp)
                )
            }
        } else {
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it.take(60) },
                label = { Text("Предмет (необязательно)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(top = 0.dp, bottom = 0.dp)
        ) {
            itemsIndexed(slots) { index, slot ->
                Column(
                    Modifier
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        var expanded by remember {
                            mutableStateOf(false)
                        }

                        Box {
                            TextButton(
                                onClick = { expanded = true }
                            ) {
                                Text(slot.day, color = palette.text)
                            }

                            DropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false }
                            ) {
                                DAY_NAMES.forEach { day ->
                                    DropdownMenuItem(
                                        text = { Text(day) },
                                        onClick = {
                                            slots[index] = slot.copy(day = day)
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = {
                                    editingTime = index to true
                                }
                            ) {
                                Text(
                                    timeText(slot.start),
                                    color = palette.text
                                )
                            }

                            Text("—", color = palette.text)

                            TextButton(
                                onClick = {
                                    editingTime = index to false
                                }
                            ) {
                                Text(
                                    timeText(slot.end),
                                    color = palette.text
                                )
                            }

                            IconButton(
                                onClick = {
                                    if (slots.size > 1) {
                                        slots.removeAt(index)
                                    }
                                }
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Удалить день",
                                    tint = palette.text
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = palette.border)
                }
            }

            item {
                TextButton(
                    onClick = {
                        slots.add(
                            EditSlot(
                                DAY_NAMES.first(),
                                480,
                                480 + duration
                            )
                        )
                    }
                ) {
                    Text("+ Добавить день", color = palette.text)
                }
            }

            if (oldTitle != null) {
                item {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        TextButton(
                            onClick = { onDelete(oldTitle) }
                        ) {
                            Text(
                                "Удалить все уроки",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            }
        }
    }

    editingTime?.let { (index, isStart) ->
        val slot = slots.getOrNull(index)

        if (slot != null) {
            val initialTime = if (isStart) slot.start else slot.end

            var hours by remember(index, isStart, initialTime) {
                mutableStateOf(
                    (initialTime / 60).toString().padStart(2, '0')
                )
            }

            var minutes by remember(index, isStart, initialTime) {
                mutableStateOf(
                    (initialTime % 60).toString().padStart(2, '0')
                )
            }

            AlertDialog(
                onDismissRequest = { editingTime = null },
                title = {
                    Text(if (isStart) "Время начала" else "Время окончания")
                },
                text = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = hours,
                            onValueChange = {
                                if (it.length <= 2 && it.all(Char::isDigit)) {
                                    hours = it
                                }
                            },
                            label = { Text("Часы") },
                            singleLine = true,
                            modifier = Modifier.width(100.dp)
                        )

                        Text(
                            ":",
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        OutlinedTextField(
                            value = minutes,
                            onValueChange = {
                                if (it.length <= 2 && it.all(Char::isDigit)) {
                                    minutes = it
                                }
                            },
                            label = { Text("Минуты") },
                            singleLine = true,
                            modifier = Modifier.width(100.dp)
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val h = hours.toIntOrNull()
                            val m = minutes.toIntOrNull()

                            if (h != null && m != null &&
                                h in 0..23 && m in 0..59
                            ) {
                                val value = h * 60 + m

                                slots[index] = if (isStart) {
                                    // Changing the start time automatically recalculates
                                    // the default end time using the duration from Settings.
                                    slot.copy(
                                        start = value,
                                        end = (value + duration).coerceAtMost(1440)
                                    )
                                } else {
                                    // The user can still manually override the end time.
                                    slot.copy(end = value)
                                }

                                editingTime = null
                            }
                        }
                    ) {
                        Text("ОК")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingTime = null }) {
                        Text("Отмена")
                    }
                }
            )
        }
    }

    if (error != null) {
        AlertDialog(
            onDismissRequest = { error = null },
            title = { Text("Ошибка") },
            text = { Text(error!!) },
            confirmButton = {
                TextButton(onClick = { error = null }) {
                    Text("ОК")
                }
            }
        )
    }
}