package com.example.schedule.presentation.components

import androidx.compose.ui.graphics.Color

data class AppPalette(
    val background: Color, val text: Color, val dayButton: Color,
    val card: Color, val currentCard: Color, val border: Color
)
fun appPalette(dark: Boolean) = if (dark) AppPalette(
    Color(0xFF2B2A2A), Color(0xFFE5E2E2), Color(0xFF454343),
    Color(0xFF3A3939), Color(0xFF486064), Color(0xFF504D4D)
) else AppPalette(
    Color(0xFFEBE5E5), Color(0xFF252424), Color(0xFFCDD5E0),
    Color(0xFFCDD5E0), Color(0xFFA1D0D8), Color(0xFFC4BDBD)
)
